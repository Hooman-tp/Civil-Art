export default function WhatsAppButton() {
  // شماره باید با کد کشور و بدون صفر ابتدایی باشد: 0912... → 98912...
  const phoneNumber = "989129245664";
  const message = encodeURIComponent("سلام، درباره پروژه‌ام سوال داشتم.");

  return (
    <a
      href={`https://wa.me/${phoneNumber}?text=${message}`}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="ارسال پیام واتساپ"
      style={{
        position: "fixed",
        right: "20px",
        bottom: "20px",
        width: "56px",
        height: "56px",
        borderRadius: "50%",
        background: "#25D366",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        boxShadow: "0 4px 16px rgba(0,0,0,0.4)",
        zIndex: 9998,
        textDecoration: "none",
      }}
    >
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path
          d="M12 2C6.48 2 2 6.48 2 12c0 1.85.5 3.58 1.38 5.07L2 22l5.07-1.33A9.94 9.94 0 0 0 12 22c5.52 0 10-4.48 10-10S17.52 2 12 2Z"
          fill="#fff"
        />
        <path
          d="M12 3.5A8.5 8.5 0 0 0 3.5 12c0 1.53.42 2.96 1.15 4.19L4 20l3.94-1.03A8.47 8.47 0 0 0 12 20.5c4.69 0 8.5-3.81 8.5-8.5S16.69 3.5 12 3.5Z"
          fill="#25D366"
        />
        <path
          d="M9.2 7.4c-.2-.44-.4-.45-.59-.46h-.5c-.18 0-.46.06-.7.32-.24.26-.9.88-.9 2.15s.93 2.5 1.06 2.67c.13.18 1.8 2.88 4.44 3.92 2.2.87 2.64.7 3.12.65.47-.04 1.53-.62 1.75-1.23.21-.6.21-1.11.15-1.22-.07-.11-.24-.18-.5-.31-.26-.13-1.53-.75-1.77-.84-.24-.09-.41-.13-.58.13-.17.26-.66.84-.81 1.02-.15.17-.3.19-.55.06-.26-.13-1.08-.4-2.06-1.27-.76-.68-1.28-1.51-1.43-1.77-.15-.26-.02-.4.11-.53.12-.12.26-.3.39-.45.13-.15.17-.26.26-.43.09-.17.04-.32-.02-.45-.06-.13-.57-1.44-.8-1.97Z"
          fill="#fff"
        />
      </svg>
    </a>
  );
}
